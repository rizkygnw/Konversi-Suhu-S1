indeks = {
    'Celcius   ': 'c',
    'Reamur    ': 'r',
    'Fahrenheit': 'f',
    'Kelvin    ': 'k'
}

